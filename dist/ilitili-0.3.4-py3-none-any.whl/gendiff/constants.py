"""Common constants."""

INDENT = '  '
ADDED = '+'
REMOVED = '-'
NESTED = 'nested'
CHANGED = 'changed'
UNCHANGED = ' '
SIMPLE = 'simple'
COMPLEX = 'complex value'
