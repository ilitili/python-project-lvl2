# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=5.4,<6.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'ilitili',
    'version': '0.3.4',
    'description': 'Show diff between two files',
    'long_description': None,
    'author': 'ilitili',
    'author_email': 'momcoveylebozo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
